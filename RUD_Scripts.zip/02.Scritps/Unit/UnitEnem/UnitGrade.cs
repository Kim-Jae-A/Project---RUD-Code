﻿public enum UnitGrade
{
    Common,
    UnCommon,
    Rare,
    Unique,
    Eqic,            
    None = -1
}