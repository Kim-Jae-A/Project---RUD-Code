﻿public enum AttackType
{
    Normal,
    Splash,
    Area
}