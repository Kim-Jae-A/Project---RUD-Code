﻿public enum UnitCode
{
    Elf,
    Magician,
    Gunner,
    Devil,
    BloodElf,
    Warrior,
    Angle,
    Mechanic,
    None = -1
}