public enum ArmourType
{
    Normal,
    Light,
    Heavy
}
