public enum EnemyType
{
    Round,
    Boss,
    Mission
} 
